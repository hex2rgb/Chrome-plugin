function fn() {
	console.log("background数组中的js方法能共享?")
}
var f=function () {
	console.log(000000)
}
test1();